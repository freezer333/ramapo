
console.log("Hello World");
console.log(NaN == NaN );
 
console.log(undefined == null );
console.log(undefined === null );