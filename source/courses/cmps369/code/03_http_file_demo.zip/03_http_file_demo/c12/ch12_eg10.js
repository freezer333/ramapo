$( document ).ready( function(){
  $( "#resizable" ).resizable();
});