$( document ).ready( function(){
  $( "#spinner" ).spinner();  
});