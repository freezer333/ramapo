$( document ).ready( function(){
  $( "#sortable" ).sortable().disableSelection();
});