$( document ).ready( function(){
  $( "#accordion" ).accordion();
});