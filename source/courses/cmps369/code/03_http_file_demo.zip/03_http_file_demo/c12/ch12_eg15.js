$( document ).ready( function(){
  $( "input" ).button()
});