$( document ).ready( function(){
  $( document ).tooltip();  
});