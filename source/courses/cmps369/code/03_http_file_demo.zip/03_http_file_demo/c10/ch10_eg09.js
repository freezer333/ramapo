for ( var i=0; i<11; i++ ) {
 document.getElementById( "numbers" ).innerHTML += "<li>" + i + " x 3 = " + (i * 3) +"</li>";
}
