var i = 1;
while ( i < 11 ) {
 document.getElementById( "numbers" ).innerHTML += "<li>" + i + " x 3 = " + (i * 3) +"</li>";
  i ++
}