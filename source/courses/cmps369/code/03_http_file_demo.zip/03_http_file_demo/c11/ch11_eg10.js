$( document ).ready( function(){
  if ( $( "#home" ).hasClass( "selected" ) ){
    $( "#home" ).removeClass( "selected" );
  }
});