$( document ).ready( function(){
 $( ".item" ).css( "color" , "blue" );
 $( "#menu .item p").css("color" , "red");
 $( "input[type=email]").css( "border" , "10px solid blue" );
});
