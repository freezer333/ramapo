$( document ).ready( 
 $( "#greeting" ).text( "It's time to learn about jQuery" )
);
