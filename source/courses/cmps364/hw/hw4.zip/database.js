const sqlite3 = require('sqlite3').verbose();
const db = new sqlite3.Database('hw4.db');

const moment = require('moment');


//  REMOVE THESE ARRAYS, THEY ARE HERE AS MOCK DATA ONLY.
var customers = [
    {id: 0, firstName: "Kasandra", lastName: "Cryer", street:"884 Meadow Lane", city:"Bardstown", state:"KY", zip:  "4004"},
    {id: 1, firstName: "Ferne", lastName: "Linebarger", street:"172 Academy Street", city:"Morton Grove", state:"IL", zip:  "60053"},
    {id: 2, firstName: "Britany", lastName: "Manges", street:"144 Fawn Court", city:"Antioch", state:"TN", zip:  "37013"}
]
var products = [
    {id:0, name: "Product A", price: 5}, 
    {id:1, name: "Product B", price: 10}, 
    {id:2, name: "Product C", price: 2.5}, 
]
var orders = [
    {id:0, customerId: 0, productId:0, date:"2017-04-12"},
    {id:1, customerId: 2, productId:1, date:"2015-08-13"},
    {id:2, customerId: 0, productId:2, date:"2019-10-18"},
    {id:3, customerId: 1, productId:0, date:"2011-03-30"},
    {id:4, customerId: 0, productId:1, date:"2017-09-01"},
    {id:5, customerId: 1, productId:2, date:"2017-12-17"},
]
///////////////////////////////////////////////////////

/**
 * This function is called at application startup.  
 * You must create the PRODUCTS, CUSTOMERS, and ORDERS tables here.
 * Be sure to use the necessary SQL commands such that if the tables
 * already exist, the statements do not cause any errors, or any
 * data to be lost.
 * 
 * 
 * 10 Points
 */
exports.build = function() {
    console.log("--- Initializing database");
    
    // Remove this when you do the implementation!
    console.log("PART 1 IS NOT COMPLETE - MAKE SURE YOU IMPLEMENT THE BUILD FUNCTION!")
}

/**
 * This function retrieves orders and constructs an array 
 * of objects with additional details about the order's
 * customer and product.  You'll need to use JOIN to 
 * bring in all the necessary data.
 * 
 * The options object MAY include an "id" property.  If it does, 
 * this function should only return one order (of matching id). 
 * If the "id" property in "options" is not defined, return all orders.
 * 
 * Required return value:
 * An array of objects with the following structure:
 * 
 *   id (order ID)
 *   date (order Date)
 *   customer {
 *      id (customer ID)
 *      firstName (customer's first name)
 *      lastName (customer's last name)
 *   }
 *   product {
 *     id (product ID)
 *     name (product name)
 *     price (product price)
 *   }
 * 
 *  You are permitted to include additional data in the customer/product sub-objects
 *  as you wish.
 * 
 * 10 Points
 */
exports.getOrders = function(options, callback) {
    // delete all this code when you do the implementation
    // this code has no business in your final program, although
    // you can use it as a guide if you think it's helpful.
    console.log("--- NOT COMPLETED:  getOrders");
    var _orders = orders.map(function(o) {
        var c = customers.filter(c => c.id == o.customerId)[0];
        var p = products.filter(p => p.id == o.productId)[0];
        return {
            id: o.id,
            date : o.date,
            customer : c, 
            product : {
               id: p.productId,
               name: p.name,
               price: p.price
            }
        }
    });
    if ( options.id ) _orders = _orders.filter(o => o.id == options.id);
    callback(null, _orders);
}

/**
 * This function retrieves customers and returns them as an array. 
 * 
 * The options object MAY include an "id" property.  If it does, 
 * this function should only return (an array of) one customer (of matching id). 
 * If the "id" property in "options" is not defined, return all orders.
 * 
 * Required return value: array of customer objects (with all customer data)
 * 
 * 5 Points
 */
exports.getCustomers = function(options, callback) {
    // delete all this code when you do the implementation
    // this code has no business in your final program, although
    // you can use it as a guide if you think it's helpful.
    console.log("--- NOT COMPLETED:  getCustomers");
    if (options.id) {
        callback(null, customers.filter(c => c.id == options.id));
    }
    else {
        callback(null,customers);
    }
}

/**
 * This function retrieves products and returns them as an array. 
 * 
 * The options object MAY include an "id" property.  If it does, 
 * this function should only return (an array of) one product (of matching id). 
 * If the "id" property in "options" is not defined, return all orders.
 * 
 * Required return value: array of product objects (with all product data)
 * 
 * 5 Points
 */
exports.getProducts = function(options, callback) {
    // delete all this code when you do the implementation
    // this code has no business in your final program, although
    // you can use it as a guide if you think it's helpful.
    console.log("--- NOT COMPLETED:  getProducts");
    if (options.id) {
        callback(null, products.filter(p => p.id == options.id));
    }
    else {
        callback(null, products);
    }
}

/**
 * This function accepts an order object an inserts it into the ORDERS table.
 * 
 * 5 Points
 */
exports.addOrder = function(order, callback) {
    console.log("--- NOT COMPLETED:  addOrder");
    callback(null, null);
}

/**
 * This function accepts a customer object an inserts or updates it into the CUSTOMERS table.
 * 
 * If customer.id is defined, the customer object represents an existing customer, and you 
 * must issue an update command.  Otherwise, insert.
 * 
 * 5 Points
 */
exports.upsertCustomer = function(customer, callback) {
    console.log("--- NOT COMPLETED:  upsertCustomer");
    callback(null, null);
}

/**
 * This function accepts a product object an inserts or updates it into the PRODUCTS table.
 * 
 * If product.id is defined, the product object represents an product customer, and you 
 * must issue an update command.  Otherwise, insert.
 * 
 * 5 Points
 */
exports.upsertProduct = function(product, callback) {
    console.log("--- NOT COMPLETED:  upsertProduct");
    callback(null, null);
}

/**
* The following delete methods all accept an ID, and should delete the Order/Customer/Product
* out of the corresponding table with the matching ID.  

*  Total 15 points for all three
*/
exports.deleteOrder = function(id, callback) {
    console.log("--- NOT COMPLETED:  deleteOrder");
    callback(null, null);
}
exports.deleteCustomer = function(id, callback) {
    console.log("--- NOT COMPLETED:  deleteCustomer");
    callback(null, null);
}
exports.deleteProduct = function(id, callback) {
    console.log("--- NOT COMPLETED:  deleteProduct");
    callback(null, null);
}


/**
 * This function builds a customer report.  The options
 * object MUST have a customerId property.  You must build a report 
 * object that contains the customer data (id, first/last name) along
 * with a list of all orders (order ID, order date, product ID, 
 * product name, and product price) and return it.
 * 
 * Note:  If the customer hasn't purchased anything, just return an empty orders
 *        array.  Hint:  LEFT JOIN will be your friend...
 * 
 * Required return value:
 * An object with the following structure:
 * 
 *   id (customer ID)
 *   firstName (customer's first name)
 *   lastName (customer's last name)
 *   orders [  // list of these....
 *      {   
 *          id (order id)
 *          date (order date)
 *          product {
 *            id (product ID)
 *            name (product name)
 *            price (product price)
 *          }
 *      }
 *   ]
 * 
 *  You are permitted to include additional data in the customer/product sub-objects
 *  as you wish.
 * 
 * 10 Points
 */
exports.customerReport = function(options, callback) {
    // delete all this code when you do the implementation
    // this code has no business in your final program, although
    // you can use it as a guide if you think it's helpful.
    console.log("--- NOT COMPLETED:  customerReport");
    // clone the object
    var report = JSON.parse(JSON.stringify(customers.filter(c => c.id == options.customerId)[0]));
    report.orders = orders.filter(o => o.customerId == report.id)
                          .map(function(o) {
                              return {
                                  id: o.id,
                                  date: o.date,
                                  product: products.filter(p => p.id == o.productId)[0]
                              }
                          });
    callback(null, report);
}

/**
 * This function builds a product report.  The options
 * object MUST have a productId property.  You must build a report 
 * object that contains the product data (id, name, price) along
 * with a list of all orders (order ID, order date, customer ID, 
 * customer first/last name) and return it.
 * 
 * Note:  If the product hasn't been purchased, just return an empty orders
 *        array.  Hint:  LEFT JOIN will be your friend...
 
 * 
 * Required return value:
 * An object with the following structure:
 * 
 *   id (product ID)
 *   name (product name)
 *   price (product price)
 *   orders [  // list of these....
 *      {   
 *          id (order id)
 *          date (order date)
 *          customer {
 *            id (customer ID)
 *            firstName (customer's first name)
 *            lastName (customer's last name)
 *          }
 *      }
 *   ]
 * 
 *  You are permitted to include additional data in the customer/product sub-objects
 *  as you wish.
 * 
 * 10 Points
 */
exports.productReport = function(options, callback) {
    // delete all this code when you do the implementation
    // this code has no business in your final program, although
    // you can use it as a guide if you think it's helpful.
    console.log("--- NOT COMPLETED:  productReport");
    // clone the object
    var report = JSON.parse(JSON.stringify(products.filter(p => p.id == options.productId)[0]));
    report.orders = orders.filter(o => o.productId == report.id)
                          .map(function(o) {
                              return {
                                  id: o.id,
                                  date: o.date,
                                  customer: customers.filter(c => c.id == o.customerId)[0]
                              }
                          });
                          console.log(report);
    callback(null, report);
    
}


/**
 * This function builds a sales report.  The options object is currently unused.
 * 
 * The function should return a list of products, where each product object
 * contains the following:
 * 
 *   id (product ID)
 *   name (product name)
 *   price (product price)
 *   sales (number of sales made)
 *   lastDate (date of last sale)
 * 
 * 10 Points
 */
exports.salesReport = function(options, callback) {
    callback(null, products.map(function(product){
        var sales = orders.filter(o=> o.productId == product.id).sort();
        var date = null;
        if ( sales.length > 0  ){
            date = sales[sales.length-1];
        }
        return {
            id:product.id,
            name:product.name,
            price:product.price,
            sales: orders.filter(o => o.productId).length,
            lastDate: date
        }
    }));
};